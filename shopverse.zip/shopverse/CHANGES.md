# ShopVerse – fixes made against the database (shopverse.sql)

No database change is needed. All fixes are in the PHP / JS code.

## Bugs fixed
1. cart_api.php – used a separate PHPSESSID session, so the cart never knew the logged-in user
   (cart_items stayed empty, checkout said "Your cart is empty"). Now uses includes/auth.php.
2. login_process.php – guest (session) cart is merged into cart_items at login (nothing called "merge").
3. admin/products_api.php, admin/categories_api.php – same session bug: no authentication at all, and
   audit_logs.user_id was always NULL. Now return 401/403 JSON unless the user is an admin.
4. admin/products_process.php renamed to Products_process.php (require in products_api.php is case-sensitive on Linux).
5. Orders_process.php – "My orders" crashed (SQLSTATE 21000) for orders with 2+ items (stray subquery).
6. Orders_process.php – customer cancel now restores stock and closes the payment, like admin cancel.
7. Checkout_process.php – re-uses an identical saved address instead of inserting a duplicate on every order.

## Pages that were showing demo data (localStorage) and now use the database
- Header cart / wishlist badges (js/app.js) -> cart_api / wishlist_api counts.
- account.php (+ js/auth.js, NEW account_api.php, NEW Account_process.php):
  real stats, recent orders, addresses (add / edit / default), wishlist preview,
  profile save (users + default address) and change-password. Email is read-only.
  Removed the fake controls that had no database column (date of birth, notification toggles, 2FA, demo delete).
- admin/customers.php (+ js/admin.js, NEW admin/customers_api.php, NEW admin/Customers_process.php).
- product-details.php – the wishlist button ("coming soon") now toggles the wishlist in the database.

## Not changed (needs you)
- includes/mail_config.php: SMTP username/password are empty, so verification / reset emails are never sent.
- Registration saves city = '' (the register form has no city field).
